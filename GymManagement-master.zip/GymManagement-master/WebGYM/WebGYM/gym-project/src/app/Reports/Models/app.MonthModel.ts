export class MonthList 
{
    public MonthName: string;
    public MonthID: string;
}