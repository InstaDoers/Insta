export class RenewalRequestModel {
    public Paymentfromdate: string
    public Paymentfromto: string
}