export class YearwiseResponseModel {
    public CurrentYear: string;
    public April: string;
    public May: string;
    public June: string;
    public July: string;
    public August: string;
    public Sept: string;
    public Oct: string;
    public Nov: string;
    public Decm: string;
    public Jan: string;
    public Feb: string;
    public March: string;
    public Total: string;
}