export class YearList 
{
    public YearName: string;
    public YearID: string;
}