export class SchemeMasterViewModel 
{
    public SchemeID: number = 0;
    public SchemeName: string = "";
    public Status: boolean = false;
    public Createddate : string = ""
}