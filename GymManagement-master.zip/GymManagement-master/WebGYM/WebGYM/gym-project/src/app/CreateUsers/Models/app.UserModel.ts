export class UserModel 
{
    public UserId: number;
    public UserName: string;
    public FullName: string;
    public EmailId: string;
    public Contactno: string;
    public Password: string;
    public Status: boolean;
    
}