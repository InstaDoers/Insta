export class PlanMasterModel{

    public PlanID : number;
    public PlanName : string;
    public PlanAmount : number;
    public ServiceTax : string;
    public SchemeID : number;
    public PeriodID : number;
}