export class GenerateRecepitViewModel 
{
    public  MemberNo : string;
    public  MemberName : string;
    public  PlanName : string;
    public  SchemeName : string;
    public  PaymentFromdt : string;
    public  PaymentTodt : string;
    public  NextRenwalDate : string;
    public  PaymentAmount : string;
    public  CreateDate : string;
    public  ServiceTax : string;     
    public  PlanAmount : string;  
    public  ServicetaxAmount : string;  
}