﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebGYM.ViewModels
{
    public class YearwiseReportViewModel
    {
        public int CurrentYear { get; set; }
        public int April { get; set; }
        public int May { get; set; }
        public int June { get; set; }
        public int July { get; set; }
        public int August { get; set; }
        public int Sept { get; set; }
        public int Oct { get; set; }
        public int Nov { get; set; }
        public int Decm { get; set; }
        public int Jan { get; set; }
        public int Feb { get; set; }
        public int March { get; set; }
        public int Total { get; set; }
    }
}
