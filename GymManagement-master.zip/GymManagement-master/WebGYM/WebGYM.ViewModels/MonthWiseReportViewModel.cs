﻿namespace WebGYM.ViewModels
{
    public class MonthWiseReportViewModel
    {
        public string MemberFName { get; set; }
        public string MemberNo { get; set; }
        public string MemberLName { get; set; }
        public string MemberMName { get; set; }
        public string CreateDate { get; set; }
        public long Total { get; set; }
        public string Paymentmonth { get; set; }
        public double PaymentAmount { get; set; }
        public string Username { get; set; }
    }
}